<?php 
	include "connection.php";
	include "navbarAdmin.php";
	//session_start();
 ?>