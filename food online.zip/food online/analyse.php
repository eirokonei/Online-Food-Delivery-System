<!DOCTYPE html>
<html>
<head>
	<title>Food Delivery System</title>
	<link type="text/css" rel="stylesheet"  href="analyse.css">
</head>

<body>
	<div class="main"> 
		<nav>
			<img src="banner_1.jpg"width="250"hieght="250">
			<UL>
				<li><a href="">Orders</a></li>
				<li><a href="">User Name</a></li>
			</UL>
		</nav>
	</div>
	<div class="cart">
		<div class="cartHead">
				Sort By
				
				<form><select name = "time" class="input">
					<option value=""> Select...</option>				
					<option value="sixmonth">6month</option>
					<option value="LastMotnh">1month</option>
					<option value="lastweek">Last Week</option>
					</select></form>
				<br>Phone Number
		</div>
		<div class="order TableHeader">
			<div>Product ID</div>
			<div>Sold amount </div>
			<div>Name</div>
		</div>
		<div class="order">
			<div>
				1012
			</div>
			<div>
				300
			</div>
			<div>
				<p class="bold">1. Chicken Cheese Delight</p>
			</div>
			
		</div>
		<div class="order">
			<div>
				1012
			</div>
			<div>
				250
			</div>
			<div>
				<p class="bold">1. Chicken Cheese Delight</p>
			</div>
			
		</div>
		<div class="order">
			<div>
				1012
			</div>
			<div>
				200
			</div>
			<div>
				<p class="bold">1. Chicken Cheese Delight</p>
			</div>
			
		</div>
		<div class="order">
			<div>
				1012
			</div>
			<div>
				100
			</div>
			<div>
				<p class="bold">1. Chicken Cheese Delight</p>
			</div>
			
		</div>
		
		
		
</body>
</html>