<?php

	$db=mysqli_connect("localhost","root","","food_delivery_system");  
					/* server name, username, passwor, database name */

?>