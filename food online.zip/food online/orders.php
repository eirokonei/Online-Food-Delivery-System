<!DOCTYPE html>
<html>
<head>
	<title>online food deilvery</title>
	<link type="text/css" rel="stylesheet"  href="orders.css">
</head>

<body>
	<div class="main"> 
		<nav>
			<img src="logo.png"width="150" height="150">
			<UL>
				<li><a href="">Orders</a></li>
				<li><a href="">User Name</a></li>
			</UL>
		</nav>
	</div>
	<div class="cart">
		<div class="cartHead">
				Order List
		</div>
		<div class="order TableHeader">
			<div>Order ID</div>
			<div>Name</div>
			<div>Quantity</div>
			<div>Estimated Time</div>
			<div>Done</div>
			<div>Cancel Order</div>
		</div>
		<div class="order">
			<div>
				1012
			</div>
			<div>
				<p class="bold">1. Chicken Cheese Delight</p>
			</div>
			<div>
				2
			</div>
			<div>
				<form><input type="text" name="EstimatedTime" placeholder="4Min"></form>
			</div>
			<div>
				<form><button class="done">√</button></form>
			</div>
			<div>
				<form><button class="cancel">X</button></form>
			</div>
		</div>
		<div class="order">
			<div>
				1012
			</div>
			<div>
				<p class="bold">1. Chicken Cheese Delight</p>
			</div>
			<div>
				2
			</div>
			<div>
				<form><input type="text" name="EstimatedTime" placeholder="4Min"></form>
			</div>
			<div>
				<form><button class="done">√</button></form>
			</div>
			<div>
				<form><button class="cancel">X</button></form>
			</div>
		</div>
		<div class="order">
			<div>
				1012
			</div>
			<div>
				<p class="bold">1. Chicken Cheese Delight</p>
			</div>
			<div>
				2
			</div>
			<div>
				<form><input type="text" name="EstimatedTime" placeholder="4Min"></form>
			</div>
			<div>
				<form><button class="done">√</button></form>
			</div>
			<div>
				<form><button class="cancel">X</button></form>
			</div>
		</div>
		<div class="order">
			<div>
				1012
			</div>
			<div>
				<p class="bold">1. Chicken Cheese Delight</p>
			</div>
			<div>
				2
			</div>
			<div>
				<form><input type="text" name="EstimatedTime" placeholder="4Min"></form>
			</div>
			<div>
				<form><button class="done">√</button></form>
			</div>
			<div>
				<form><button class="cancel">X</button></form>
			</div>
		</div>
		<div class="order">
			<div>
				1012
			</div>
			<div>
				<p class="bold">1. Chicken Cheese Delight</p>
			</div>
			<div>
				2
			</div>
			<div>
				<form><input type="text" name="EstimatedTime" placeholder="4Min"></form>
			</div>
			<div>
				<form><button class="done">√</button></form>
			</div>
			<div>
				<form><button class="cancel">X</button></form>
			</div>
		</div>
		
</body>
</html>